execute if score @s vimiCoal matches 1.. run setblock 20000016 1 20000016 coal_ore
execute if score @s vimiLapis matches 1.. run setblock 20000016 1 20000016 lapis_ore
execute if score @s vimiIron matches 1.. run setblock 20000016 1 20000016 iron_ore
execute if score @s vimiGold matches 1.. run setblock 20000016 1 20000016 gold_ore
execute if score @s vimiDiamond matches 1.. run setblock 20000016 1 20000016 diamond_ore
execute if score @s vimiEmerald matches 1.. run setblock 20000016 1 20000016 emerald_ore
execute if score @s vimiRedstone matches 1.. run setblock 20000016 1 20000016 redstone_ore
execute if score @s vimiQuartz matches 1.. run setblock 20000016 1 20000016 nether_quartz_ore
execute if score @s vimiNGold matches 1.. run setblock 20000016 1 20000016 nether_gold_ore
execute if score @s vimiDebris matches 1.. run setblock 20000016 1 20000016 ancient_debris
execute if score @s vimiGlowstone matches 1.. run setblock 20000016 1 20000016 glowstone
execute if score @s vimiObsidian matches 1.. run setblock 20000016 1 20000016 obsidian
execute if score @s vimiIce matches 1.. run setblock 20000016 1 20000016 ice
execute if score @s vimiPackedIce matches 1.. run setblock 20000016 1 20000016 packed_ice
execute if score @s vimiBlueIce matches 1.. run setblock 20000016 1 20000016 blue_ice

