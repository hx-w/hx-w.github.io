execute if block 20000016 1 20000016 #vimi:single_state run function vimi:single_state/item_pos
execute if block 20000016 1 20000016 #vimi:multi_state run function vimi:multi_state/item_pos