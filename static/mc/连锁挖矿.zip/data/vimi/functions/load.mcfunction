# 加入记分板
scoreboard objectives add vimiTemp dummy
scoreboard objectives add vimiExp dummy

# 斧
scoreboard objectives add vimiAxeW minecraft.used:minecraft.wooden_axe
scoreboard objectives add vimiAxeS minecraft.used:minecraft.stone_axe
scoreboard objectives add vimiAxeI minecraft.used:minecraft.iron_axe
scoreboard objectives add vimiAxeG minecraft.used:minecraft.golden_axe
scoreboard objectives add vimiAxeD minecraft.used:minecraft.diamond_axe
scoreboard objectives add vimiAxeN minecraft.used:minecraft.netherite_axe

# 镐
scoreboard objectives add vimiPickW minecraft.used:minecraft.wooden_pickaxe
scoreboard objectives add vimiPickS minecraft.used:minecraft.stone_pickaxe
scoreboard objectives add vimiPickI minecraft.used:minecraft.iron_pickaxe
scoreboard objectives add vimiPickG minecraft.used:minecraft.golden_pickaxe
scoreboard objectives add vimiPickD minecraft.used:minecraft.diamond_pickaxe
scoreboard objectives add vimiPickN minecraft.used:minecraft.netherite_pickaxe

# 锹
scoreboard objectives add vimiSpadeW minecraft.used:minecraft.wooden_shovel
scoreboard objectives add vimiSpadeS minecraft.used:minecraft.stone_shovel
scoreboard objectives add vimiSpadeI minecraft.used:minecraft.iron_shovel
scoreboard objectives add vimiSpadeG minecraft.used:minecraft.golden_shovel
scoreboard objectives add vimiSpadeD minecraft.used:minecraft.diamond_shovel
scoreboard objectives add vimiSpadeN minecraft.used:minecraft.netherite_shovel

# 锄
scoreboard objectives add vimiHoeW minecraft.used:minecraft.wooden_hoe
scoreboard objectives add vimiHoeS minecraft.used:minecraft.stone_hoe
scoreboard objectives add vimiHoeI minecraft.used:minecraft.iron_hoe
scoreboard objectives add vimiHoeG minecraft.used:minecraft.golden_hoe
scoreboard objectives add vimiHoeD minecraft.used:minecraft.diamond_hoe
scoreboard objectives add vimiHoeN minecraft.used:minecraft.netherite_hoe

# 剪刀
scoreboard objectives add vimiShears minecraft.used:minecraft.shears

# 作物
scoreboard objectives add vimiMelon minecraft.mined:minecraft.melon
scoreboard objectives add vimiPumpkin minecraft.mined:minecraft.pumpkin
scoreboard objectives add vimiMushStem minecraft.mined:minecraft.mushroom_stem
scoreboard objectives add vimiBrownMush minecraft.mined:minecraft.brown_mushroom_block
scoreboard objectives add vimiRedMush minecraft.mined:minecraft.red_mushroom_block
scoreboard objectives add vimiBeetroots minecraft.mined:minecraft.beetroots
scoreboard objectives add vimiWheat minecraft.mined:minecraft.wheat
scoreboard objectives add vimiPotato minecraft.mined:minecraft.potatoes
scoreboard objectives add vimiCarrot minecraft.mined:minecraft.carrots
scoreboard objectives add vimiWart minecraft.mined:minecraft.nether_wart
scoreboard objectives add vimiSugarCane minecraft.mined:minecraft.sugar_cane

# 矿石
scoreboard objectives add vimiCoal minecraft.mined:minecraft.coal_ore
scoreboard objectives add vimiLapis minecraft.mined:minecraft.lapis_ore
scoreboard objectives add vimiIron minecraft.mined:minecraft.iron_ore
scoreboard objectives add vimiGold minecraft.mined:minecraft.gold_ore
scoreboard objectives add vimiRedstone minecraft.mined:minecraft.redstone_ore
scoreboard objectives add vimiDiamond minecraft.mined:minecraft.diamond_ore
scoreboard objectives add vimiEmerald minecraft.mined:minecraft.emerald_ore
scoreboard objectives add vimiQuartz minecraft.mined:minecraft.nether_quartz_ore
scoreboard objectives add vimiNGold minecraft.mined:minecraft.nether_gold_ore
scoreboard objectives add vimiDebris minecraft.mined:minecraft.ancient_debris

# 沙土质
scoreboard objectives add vimiSand minecraft.mined:minecraft.sand
scoreboard objectives add vimiRedSand minecraft.mined:minecraft.red_sand
scoreboard objectives add vimiGravel minecraft.mined:minecraft.gravel
scoreboard objectives add vimiClay minecraft.mined:minecraft.clay
scoreboard objectives add vimiSoulSand minecraft.mined:minecraft.soul_sand
scoreboard objectives add vimiSoulSoil minecraft.mined:minecraft.soul_soil
scoreboard objectives add vimiSnow minecraft.mined:minecraft.snow

# 原木
scoreboard objectives add vimiOakLog minecraft.mined:minecraft.oak_log
scoreboard objectives add vimiBirchLog minecraft.mined:minecraft.birch_log
scoreboard objectives add vimiSpruceLog minecraft.mined:minecraft.spruce_log
scoreboard objectives add vimiDarkOakLog minecraft.mined:minecraft.dark_oak_log
scoreboard objectives add vimiJungleLog minecraft.mined:minecraft.jungle_log
scoreboard objectives add vimiAcaciaLog minecraft.mined:minecraft.acacia_log
scoreboard objectives add vimiCrimsonStem minecraft.mined:minecraft.crimson_stem
scoreboard objectives add vimiWarpedStem minecraft.mined:minecraft.warped_stem

# 树叶
scoreboard objectives add vimiOakLeaf minecraft.mined:minecraft.oak_leaves
scoreboard objectives add vimiBirchLeaf minecraft.mined:minecraft.birch_leaves
scoreboard objectives add vimiSpruceLeaf minecraft.mined:minecraft.spruce_leaves
scoreboard objectives add vimiDarkOakLeaf minecraft.mined:minecraft.dark_oak_leaves
scoreboard objectives add vimiJungleLeaf minecraft.mined:minecraft.jungle_leaves
scoreboard objectives add vimiAcaciaLeaf minecraft.mined:minecraft.acacia_leaves

# 冰
scoreboard objectives add vimiIce minecraft.mined:minecraft.ice
scoreboard objectives add vimiPackedIce minecraft.mined:minecraft.packed_ice
scoreboard objectives add vimiBlueIce minecraft.mined:minecraft.blue_ice

# 草
scoreboard objectives add vimiGrass minecraft.mined:minecraft.grass
scoreboard objectives add vimiTallGrass minecraft.mined:minecraft.tall_grass
scoreboard objectives add vimiFern minecraft.mined:minecraft.fern
scoreboard objectives add vimiLargeFern minecraft.mined:minecraft.large_fern

# 其它方块
scoreboard objectives add vimiGlowstone minecraft.mined:minecraft.glowstone
scoreboard objectives add vimiObsidian minecraft.mined:minecraft.obsidian
scoreboard objectives add vimiNetherWBlock minecraft.mined:minecraft.nether_wart_block
scoreboard objectives add vimiWarpedWBlock minecraft.mined:minecraft.warped_wart_block
scoreboard objectives add vimiShroomlight minecraft.mined:minecraft.shroomlight
scoreboard objectives add vimiVine minecraft.mined:minecraft.vine
scoreboard objectives add vimiCobweb minecraft.mined:minecraft.cobweb

# 种子树苗需求
scoreboard objectives add vimiBeetrNeed dummy
scoreboard objectives add vimiWheatNeed dummy
scoreboard objectives add vimiPotatoNeed dummy
scoreboard objectives add vimiCarrotNeed dummy
scoreboard objectives add vimiWartNeed dummy
scoreboard objectives add vimiAcaciaSap dummy
scoreboard objectives add vimiBirchSap dummy
scoreboard objectives add vimiDarkOakSap dummy
scoreboard objectives add vimiJungleSap dummy
scoreboard objectives add vimiOakSap dummy
scoreboard objectives add vimiSpruceSap dummy

# 破坏的方块数=需要消耗的饥饿值÷200
scoreboard objectives add vimiDestroyBlock dummy

# 是否需要潜行
scoreboard objectives add vimiNeedSneak trigger {"text": "连锁矿工：无需潜行;Vein Miner: Without Sneaking"}

execute as @a run function vimi:load_player

scoreboard players set 10 vimiTemp 10

# 强加载区块
forceload add 20000016 20000016
execute in the_nether run forceload add 20000016 20000016
execute in the_end run forceload add 20000016 20000016

# 防止挖掘大量方块造成的溢出
gamerule maxCommandChainLength 1000000



schedule function vimi:food 1s replace
schedule function vimi:load_check 10s replace

