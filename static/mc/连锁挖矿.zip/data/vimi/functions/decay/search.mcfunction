kill @s

execute positioned ~-1 ~-1 ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~-1 ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~-1 ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~ ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~ ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~ ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~1 ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~-1 ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~-1 ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~-1 ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~ ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~ ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~1 ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~1 ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~ ~1 ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~-1 ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~-1 ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~-1 ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~ ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~ ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~ ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~1 ~ if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #vimi:leaves[persistent=false,distance=7] run function vimi:decay/destroy
