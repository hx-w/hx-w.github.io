#
execute as @a[scores={vimiNeedSneak=..0},predicate=!vimi:sneak,predicate=vimi:tool,predicate=vimi:score_tool] at @s run function vimi:test_used_tool
execute as @a[scores={vimiNeedSneak=1..},predicate=vimi:sneak,predicate=vimi:tool,predicate=vimi:score_tool] at @s run function vimi:test_used_tool

# 重置分数
function vimi:reset_score

# 扣除种子树苗
function vimi:clear_seed/type

# 快速落叶
## 物品
execute as @e[type=item,nbt={Item:{tag:{vimiMarker:1b}}}] at @s run function vimi:decay/search

## 药水云
# execute as @e[type=area_effect_cloud,tag=vimi_decay_marker,nbt={Age:15}] at @s run function vimi:decay/start

# 清除技术性物品
# kill @e[type=item,nbt={Item:{tag:{vimiMarker:1b}}}]

# 防止有人刷熔炉
execute positioned 20000016 1 20000016 run kill @a[gamemode=survival,distance=..10,name=!Phoupraw]

scoreboard players enable @a vimiNeedSneak
