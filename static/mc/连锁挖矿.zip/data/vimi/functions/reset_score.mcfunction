# 斧
scoreboard players reset @e vimiAxeW
scoreboard players reset @e vimiAxeS
scoreboard players reset @e vimiAxeI
scoreboard players reset @e vimiAxeG
scoreboard players reset @e vimiAxeD
scoreboard players reset @e vimiAxeN

# 镐
scoreboard players reset @e vimiPickW
scoreboard players reset @e vimiPickS
scoreboard players reset @e vimiPickI
scoreboard players reset @e vimiPickG
scoreboard players reset @e vimiPickD
scoreboard players reset @e vimiPickN

# 锹
scoreboard players reset @e vimiSpadeW
scoreboard players reset @e vimiSpadeS
scoreboard players reset @e vimiSpadeI
scoreboard players reset @e vimiSpadeG
scoreboard players reset @e vimiSpadeD
scoreboard players reset @e vimiSpadeN

# 锄
scoreboard players reset @e vimiHoeW
scoreboard players reset @e vimiHoeS
scoreboard players reset @e vimiHoeI
scoreboard players reset @e vimiHoeG
scoreboard players reset @e vimiHoeD
scoreboard players reset @e vimiHoeN

# 剪刀
scoreboard players reset @e vimiShears

# 作物
scoreboard players reset @e vimiMelon
scoreboard players reset @e vimiPumpkin
scoreboard players reset @e vimiMushStem
scoreboard players reset @e vimiBrownMush
scoreboard players reset @e vimiRedMush
scoreboard players reset @e vimiBeetroots
scoreboard players reset @e vimiWheat
scoreboard players reset @e vimiPotato
scoreboard players reset @e vimiCarrot
scoreboard players reset @e vimiWart
scoreboard players reset @e vimiSugarCane

# 矿石
scoreboard players reset @e vimiCoal
scoreboard players reset @e vimiLapis
scoreboard players reset @e vimiIron
scoreboard players reset @e vimiGold
scoreboard players reset @e vimiRedstone
scoreboard players reset @e vimiDiamond
scoreboard players reset @e vimiEmerald
scoreboard players reset @e vimiQuartz
scoreboard players reset @e vimiNGold
scoreboard players reset @e vimiDebris

# 沙土质
scoreboard players reset @e vimiSand
scoreboard players reset @e vimiRedSand
scoreboard players reset @e vimiGravel
scoreboard players reset @e vimiClay
scoreboard players reset @e vimiSoulSand
scoreboard players reset @e vimiSoulSoil
scoreboard players reset @e vimiSnow

# 原木
scoreboard players reset @e vimiOakLog
scoreboard players reset @e vimiBirchLog
scoreboard players reset @e vimiSpruceLog
scoreboard players reset @e vimiDarkOakLog
scoreboard players reset @e vimiJungleLog
scoreboard players reset @e vimiAcaciaLog
scoreboard players reset @e vimiCrimsonStem
scoreboard players reset @e vimiWarpedStem

# 树叶
scoreboard players reset @e vimiOakLeaf
scoreboard players reset @e vimiBirchLeaf
scoreboard players reset @e vimiSpruceLeaf
scoreboard players reset @e vimiDarkOakLeaf
scoreboard players reset @e vimiJungleLeaf
scoreboard players reset @e vimiAcaciaLeaf

# 冰
scoreboard players reset @e vimiIce
scoreboard players reset @e vimiPackedIce
scoreboard players reset @e vimiBlueIce

# 草
scoreboard players reset @e vimiGrass
scoreboard players reset @e vimiTallGrass
scoreboard players reset @e vimiFern
scoreboard players reset @e vimiLargeFern

# 其它方块
scoreboard players reset @e vimiGlowstone
scoreboard players reset @e vimiObsidian
scoreboard players reset @e vimiNetherWBlock
scoreboard players reset @e vimiWarpedWBlock
scoreboard players reset @e vimiShroomlight
scoreboard players reset @e vimiVine
scoreboard players reset @e vimiCobweb