# 初始化
scoreboard players set @s[tag=!vimi_need_sneak_set] vimiNeedSneak 1
tag @s[tag=!vimi_need_sneak_set] add vimi_need_sneak_set
tellraw @s [{"text":"欢迎使用连锁矿工！\n","color":"aqua","bold": true},{"text":"Welcome to use Vein Miner!\nby Ph-苯"}]