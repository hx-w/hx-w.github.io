function vimi:multi_state/search
execute if block 20000016 1 20000016 acacia_log if block ~ ~-1 ~ #vimi:dirt_like run function vimi:sow/acacia_sapling
execute if block 20000016 1 20000016 birch_log if block ~ ~-1 ~ #vimi:dirt_like run function vimi:sow/birch_sapling
execute if block 20000016 1 20000016 dark_oak_log if block ~ ~-1 ~ #vimi:dirt_like run function vimi:sow/dark_oak_sapling
execute if block 20000016 1 20000016 jungle_log if block ~ ~-1 ~ #vimi:dirt_like run function vimi:sow/jungle_sapling
execute if block 20000016 1 20000016 oak_log if block ~ ~-1 ~ #vimi:dirt_like run function vimi:sow/oak_sapling
execute if block 20000016 1 20000016 spruce_log if block ~ ~-1 ~ #vimi:dirt_like run function vimi:sow/spruce_sapling
function vimi:final_loot
