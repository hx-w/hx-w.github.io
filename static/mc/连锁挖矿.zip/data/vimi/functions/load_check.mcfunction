schedule function vimi:load_check 10s replace

execute as @a[tag=!vimi_need_sneak_set] run function vimi:load_player